import { createRoot } from 'react-dom/client'
import { createPortal } from 'react-dom'
import { useEffect, useState } from 'react'
import App from './App.jsx'

const AppWrapper = () => {
  const [popupData, setPopupData] = useState(null);
  const [popupElement, setPopupElement] = useState(null);

  useEffect(() => {
    const checkPopup = () => {
      const diagram = document.getElementById('edit-diagram');

      if (diagram && document.body.contains(diagram)) {
        const config = {
          nodeSpacing: diagram.getAttribute('data-node-spacing'),
          edgeSpacing: diagram.getAttribute('data-edge-spacing'),
          output: diagram.getAttribute('data-output'),
          format: diagram.getAttribute('data-format'),
          editState: diagram.getAttribute('edit-state'),
          fieldName: diagram.getAttribute('data-field-name'),
        };

        setPopupData(config);
        setPopupElement(diagram);
      } else {
        setPopupData(null);
        setPopupElement(null);
      }
    };

    checkPopup();

    const observer = new MutationObserver(checkPopup);

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    return () => observer.disconnect();
  }, []);

  if (!popupData || !popupElement || !document.body.contains(popupElement)) {
    return null;
  }

  return createPortal(
    <App key={popupElement} config={popupData} />,
    popupElement
  );
};

const appContainer = document.createElement('div');
appContainer.id = 'react-app-root';
appContainer.style.display = 'none';
document.body.appendChild(appContainer);

const root = createRoot(appContainer);
root.render(<AppWrapper />);
