import IconifyField from './iconify_field'

export default {
  IconifyField,
}
