<template>
  <SearchForm />
</template>
