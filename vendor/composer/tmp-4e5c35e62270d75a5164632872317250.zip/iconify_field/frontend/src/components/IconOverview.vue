<script setup lang="ts">
import { ofetch } from 'ofetch'

const props = defineProps({
  collection: {
    type: String,
    required: true,
  },
  searchQuery: {
    type: String,
    required: true,
  },
})

const Drupal = useDrupal()

const itemsPerPage = ref(24)

const loading = ref(true)
const filteredIcons = ref<string[]>([])

interface IconResponse {
  icons?: string[]
  error?: string
}

async function fetchIcons(): Promise<IconResponse> {
  loading.value = true

  const response: IconResponse = await ofetch(`/api/iconify_field/icons/${props.collection}`)
    .catch((error) => {
      console.error(error)
      return { icons: [], error }
    })
    .finally(() => {
      loading.value = false
    })

  return response
}

const icons = ref<string[]>([])
const error = ref<string>()

const { workerFn, workerTerminate } = useWebWorkerFn((icons: string[], searchQuery: string) => {
  if (searchQuery === '')
    return icons

  return icons?.filter(icon => icon.includes(searchQuery))
})

const page = ref(1)

watch(() => props.collection, async () => {
  const response = await fetchIcons()

  icons.value = response.icons ?? []
  error.value = response.error

  workerTerminate()
  filteredIcons.value = await workerFn(
    JSON.parse(JSON.stringify(icons.value)),
    props.searchQuery,
  )

  page.value = 1
}, {
  immediate: true,
})

watch(() => props.searchQuery, async () => {
  workerTerminate()
  filteredIcons.value = await workerFn(
    JSON.parse(JSON.stringify(icons.value)),
    props.searchQuery,
  )

  page.value = 1
})

const pagerBtns = ref<HTMLDivElement | null>(null)

function goToPage(newPage: number) {
  page.value = newPage

  if (!pagerBtns.value)
    return

  setTimeout(() => {
    pagerBtns.value?.scrollIntoView({
      behavior: 'instant',
      block: 'end',
    })
  }, 0)
}
</script>

<template>
  <div>
    <Spinner v-if="loading" />

    <div v-else>
      <p v-if="error">
        {{ error }}
      </p>

      <div
        v-if="filteredIcons?.length"
        class="icons form-item"
      >
        <IconItem
          v-for="icon in filteredIcons?.slice((page - 1) * itemsPerPage, page * itemsPerPage)"
          :key="icon"
          :icon="icon"
          :name="icon.replace(`${props.collection}:`, '')"
        />
      </div>

      <div
        ref="pagerBtns"
        class="pager--buttons"
      >
        <button
          :disabled="page === 1"
          class="button button--primary"
          @click.prevent="goToPage(page - 1)"
        >
          {{ Drupal.t('Previous') }}
        </button>

        <span>
          {{ page }} / {{ Math.max(1, Math.ceil((filteredIcons?.length ?? 0) / itemsPerPage)) }}
        </span>

        <button
          :disabled="page * itemsPerPage >= (filteredIcons?.length ?? 0)"
          class="button button--primary"
          @click.prevent="goToPage(page + 1)"
        >
          {{ Drupal.t('Next') }}
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.icons {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(14rem, 1fr));
  gap: 1rem;
}

.pager--buttons {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.pager--buttons > .button {
  margin-inline: 0;
}
</style>
