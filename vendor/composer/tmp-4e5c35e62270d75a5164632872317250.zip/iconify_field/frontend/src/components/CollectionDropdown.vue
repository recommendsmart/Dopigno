<script setup lang="ts">
import { ofetch } from 'ofetch'

const Drupal = useDrupal()

const loading = ref(true)

interface Collection {
  [key: string]: {
    name: string
    total: number
    author: {
      name: string
      url: string
    }
    license: {
      title: string
      spdx: string
      url: string
    }
    samples: string[]
    height: number
    category: string
    palette: boolean
  }
}

interface Collections {
  collections?: Collection
  error?: string
}

const form = document.querySelector('.iconify-field-icon-picker-form') as HTMLFormElement
const url = new URL(form?.action ?? 'http://localhost')
const defaultCollection = url.searchParams.get('default_collection')
const availableCollections = computed(() => {
  const collections = url.searchParams.get('collections')

  if (!collections)
    return

  return collections.split(',')
})

const { collections }: Collections = await ofetch(`/api/iconify_field/collections?${url.searchParams}`)
  .catch((error) => {
    console.error(error)
    return { icons: [], error }
  })
  .finally(() => {
    loading.value = false
  })

const model = defineModel()

// Set default collection from query parameter.
model.value = defaultCollection

if (!defaultCollection || !(defaultCollection in (collections ?? {})))
  model.value = Object.keys(collections ?? {})[0]

const collectionCategories = computed(() => {
  const categories: { [key: string]: Collection } = {}

  for (const collection_key in collections) {
    const collection = collections[collection_key]

    categories[collection.category ?? 'Misc'] = {
      ...categories[collection.category ?? 'Misc'],
      [collection_key]: collection,
    }
  }

  return categories
})
</script>

<template>
  <div
    v-show="availableCollections?.length !== 1"
    class="form-item"
  >
    <label for="iconify-field--collection" class="form-item__label">
      {{ Drupal.t('Collection') }}
    </label>

    <select
      v-model="model"
      class="form-element form-element--type-select"
    >
      <optgroup
        v-for="category, category_key in collectionCategories"
        :key="category_key"
        :label="category_key.toString() ?? ''"
      >
        <option
          v-for="collection, collection_key in category"
          :key="collection_key"
          :value="collection_key"
        >
          {{ collection.name }} - {{ collection.license.title }} ({{ collection.total }})
        </option>
      </optgroup>
    </select>
  </div>
</template>

<style scoped>
.form-element {
  width: 100%;
}
</style>
