<script setup lang="ts">
const collection = ref<string>()
const searchQuery = ref('')
</script>

<template>
  <div>
    <Suspense>
      <CollectionDropdown
        v-model="collection"
      />
    </Suspense>

    <SearchBar
      v-model="searchQuery"
    />

    <Suspense>
      <IconOverview
        v-if="collection"
        :collection="collection"
        :search-query="searchQuery"
      />
    </Suspense>
  </div>
</template>
