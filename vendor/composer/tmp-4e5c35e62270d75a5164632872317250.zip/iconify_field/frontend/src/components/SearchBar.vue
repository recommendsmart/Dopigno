<script setup lang="ts">
const Drupal = useDrupal()

const model = defineModel()
</script>

<template>
  <div class="search-bar form-item">
    <label for="iconify-field--search" class="form-item__label">
      {{ Drupal.t('Search') }}
    </label>

    <input
      id="iconify-field--search"
      v-model="model"
      type="search"
      class="form-element form-element--type-text"
      :placeholder="Drupal.t('Icon name')"
    >

    <div class="form-item__description">
      {{ Drupal.t('Search for an icon by name.') }}
    </div>
  </div>
</template>

<style scoped>
.form-element {
  width: 100%;
}
</style>
