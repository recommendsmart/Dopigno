<script setup lang="ts">
import { Icon } from '@iconify/vue'

const props = defineProps({
  icon: {
    type: String,
    required: false,
  },
  name: {
    type: String,
    required: true,
  },
})

function selectIcon(e: MouseEvent) {
  const target = e.target as HTMLElement
  const icon = target.querySelector('svg')?.outerHTML

  const event = new CustomEvent('iconify-field-pick-icon', {
    detail: {
      icon: props.icon ? icon : '',
      text: props.icon ? props.icon : '',
    },
  })

  document.body.dispatchEvent(event)
}
</script>

<template>
  <div
    class="icon--wrapper"
    role="button"
    @click.prevent="selectIcon"
  >
    <Icon
      class="icon iconify-field"
      :icon="icon || 'mdi:close'"
    />
    <span>{{ name }}</span>
  </div>
</template>

<style scoped>
.icon--wrapper {
  align-items: center;
  border-radius: .75rem;
  border: 1px solid #ccc;
  cursor: pointer;
  display: inline-flex;
  flex-direction: column;
  padding: 1rem .5rem;
  text-align: center;
}

.icon--wrapper > * {
  pointer-events: none;
}

.icon {
  font-size: 2.5rem;
}
</style>
