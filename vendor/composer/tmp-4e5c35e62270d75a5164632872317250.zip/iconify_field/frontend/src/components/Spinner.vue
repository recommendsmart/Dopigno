<template>
  <div class="spinner">
    <div class="ajax-progress ajax-progress--throbber">
      <div class="ajax-progress__throbber" />
    </div>
  </div>
</template>

<style scoped>
.spinner {
  display: flex;
  justify-content: center;
}
</style>
